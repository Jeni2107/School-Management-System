package com.example.demo;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

public interface DetailRepositary extends JpaRepository<Detail,String>
{
	    Detail findByEmail(String email);
	    List<Detail> findByRole(String role);
	    List<Detail> findAllByRole(String role, Pageable page);
	    long countByRole(String role);
	    List<Detail> findByDepartmentAndRole(String department, String role);
	    @Query("SELECT d FROM Detail d WHERE d.roll_no = :roll_no")
	    Detail findByRoll_no(@Param("roll_no") int roll_no);
	    @Modifying
	    @Transactional
	    @Query("update Detail d set d.name=:name, d.roll_no=:roll_no, d.year=:year, d.stream=:stream, d.department=:department, d.role=:role where d.email=:email")
	    void updateStudentDetail(@Param("email") String email, @Param("name") String name, 
	                            @Param("roll_no") int roll_no, @Param("year") String year, 
	                            @Param("stream") String stream, @Param("department") String department, 
	                            @Param("role") String role);

	    @Modifying
	    @Transactional
	    @Query("update Detail d set d.name=:name, d.stream=:stream, d.department=:department, d.role=:role where d.email=:email")
	    void updateStaffDetail(@Param("email") String email, @Param("name") String name, 
	                           @Param("stream") String stream, @Param("department") String department, 
	                           @Param("role") String role);
}
