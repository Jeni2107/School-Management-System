package com.example.demo;
public class StudentsNotFoundException extends Exception {
    public StudentsNotFoundException(String message) {
        super(message);
    }
}
