package com.example.demo;

import java.text.SimpleDateFormat;
import java.time.DayOfWeek;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

@Controller
public class MainController {
	@Autowired
	private LoginRepositary login;
	@Autowired
	private DetailRepositary detailData;
	@Autowired
	private JavaMailSender javaMailSender;
	@RequestMapping(value = "/")
	public String signin(HttpSession session) {
	
		try {
			if (session.getAttribute("email") != null) {
				return "redirect:/page";
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return "index";
	}
	@RequestMapping(value = "/index")
	public String index(HttpSession session) {
	
		try {
			if (session.getAttribute("email") != null) {
				return "redirect:/page";
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return "index";
	}
	@GetMapping(value = "/admin")
	public String admin(HttpSession session, HttpServletResponse response, Model model) {
		response.setHeader("Cache-Control", "no-cache, no-store, must-revalidate");
		response.setHeader("Pragma", "no-cache");
		response.setHeader("Expires", "0");
		System.out.println(session.getAttribute("email"));
		try {
			if (session.getAttribute("email") != null) {
				String email = session.getAttribute("email").toString();
				Login user = login.findByEmail((email.trim()));
				if (user != null) {
					session.setAttribute("email", user.getEmail());
					Detail admin = detailData.findByEmail(email);
					session.setAttribute("admin", admin);
					Login adminpass = login.findByEmail(email);
					session.setAttribute("adminpass", adminpass);
					List<Detail> studentLogin = detailData.findByRole("student");
					session.setAttribute("students", studentLogin);
					return "/adminPage";
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return "index";
	}

	@GetMapping(value = "/staff")
	public String staff(HttpSession session, HttpServletResponse response, Model model) {
		response.setHeader("Cache-Control", "no-cache, no-store, must-revalidate");
		response.setHeader("Pragma", "no-cache");
		response.setHeader("Expires", "0");
		try {
			if (session.getAttribute("email") != null) {
				String email = session.getAttribute("email").toString();
				Login user = login.findByEmail((email.trim()));
				if (user != null) {
					session.setAttribute("email", user.getEmail());
					Login staffLoginpass = login.findByEmail(email);
					session.setAttribute("staffpass", staffLoginpass);
					Detail staffLogin = detailData.findByEmail(email);
					session.setAttribute("staff", staffLogin);
					return "staffPage";
				}
			}
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
		return "index";
	}

	@GetMapping(value = "/student")
	public String student(HttpSession session, HttpServletResponse response, Model model) {
		response.setHeader("Cache-Control", "no-cache, no-store, must-revalidate");
		response.setHeader("Pragma", "no-cache");
		response.setHeader("Expires", "0");
		try {
			if (session.getAttribute("email") != null) {
				String email = session.getAttribute("email").toString();
				Login user = login.findByEmail((email.trim()));
				if (user != null) {
					Detail studentLogin = detailData.findByEmail(email);
					session.setAttribute("students", studentLogin);
					Login studentLoginPass = login.findByEmail(email);
					session.setAttribute("student", studentLoginPass);
					return "studentPage";
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return "index";
	}

	@RequestMapping(value = "/login")
	public String signin(@RequestParam String email, @RequestParam String password, Model model, HttpSession session) {
		try {
			Login user = login.findByEmail((email.trim()));
			if (user != null) {
				  if (password.equals(user.getPassword().trim())) {
					session.setAttribute("email", user.getEmail());
					String role = user.getRole();
					if (role.equals("admin")) {
						return "redirect:/admin";
					} else if (role.equals("student")) {
						return "redirect:/student";
					} else if (role.equals("staff")) {
						return "redirect:/staff";
					}
					return "index";
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		model.addAttribute("Error", "User name or password is incorrect");
		return "index";
	}

	@RequestMapping(value = "/page")
	public String page(HttpSession session, Model model, HttpServletResponse response) {
		response.setHeader("Cache-Control", "no-cache, no-store, must-revalidate");
		response.setHeader("Pragma", "no-cache");
		response.setHeader("Expires", "0");
		try {
			if (session.getAttribute("email") != null) {
				String email = session.getAttribute("email").toString();
				Login user = login.findByEmail((email.trim()));
				if (user != null) {
					session.setAttribute("email", user.getEmail());
					String role = user.getRole();
					if (role.equals("admin")) {
						Detail admin = detailData.findByEmail(email);
						session.setAttribute("admin", admin);
						Login adminpass = login.findByEmail(email);
						session.setAttribute("adminpass", adminpass);
						List<Detail> studentLogin = detailData.findByRole("student");
						model.addAttribute("students", studentLogin);
						return "/adminPage";
					} else if (role.equals("student")) {
						Detail studentLogin = detailData.findByEmail(email);
						session.setAttribute("students", studentLogin);
						Login studentLoginPass = login.findByEmail(email);
						session.setAttribute("student", studentLoginPass);
						return "studentPage";
					} else if (role.equals("staff")) {
						Login staffLoginpass = login.findByEmail(email);
						session.setAttribute("staffpass", staffLoginpass);
						Detail staffLogin = detailData.findByEmail(email);
						session.setAttribute("staff", staffLogin);
						return "staffPage";
					}
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return "index";
	}

	@GetMapping("/logout")
	public String logout(HttpSession session, HttpServletResponse response, HttpServletRequest request) {
		session.removeAttribute("email");
		session.invalidate();
		return "index";
	}

	@RequestMapping("adddetails")
	public String adddetail(@RequestParam("role") String selectedRole, Model model, HttpServletResponse response,
			HttpSession session) {
		response.setHeader("Cache-Control", "no-cache, no-store, must-revalidate");
		response.setHeader("Pragma", "no-cache");
		response.setHeader("Expires", "0");
		try {
			if (session.getAttribute("email") != null) {
				if (selectedRole.equals("student")) {
					model.addAttribute("selectedRole", selectedRole);
					return "addstudent";
				} else if (selectedRole.equals("staff")) {
					model.addAttribute("selectedRole", selectedRole);
					return "addstaff";
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return "index";
	}

	@RequestMapping(value = "/submit")
	public String addDetail(Detail detail, String email, Model model, HttpSession session,
			HttpServletResponse response) {
		response.setHeader("Cache-Control", "no-cache, no-store, must-revalidate");
		response.setHeader("Pragma", "no-cache");
		response.setHeader("Expires", "0");
		try {
			if (session.getAttribute("email") != null) {
				detailData.save(detail);
				String defaultPassword = "user@123";
				String role = detail.getRole();
				Login userLogin = new Login();
				userLogin.setEmail(email);
				userLogin.setPassword(defaultPassword);
				userLogin.setRole(role);
				login.save(userLogin);
				List<Detail> studentDetails = detailData.findByRole(role);
				session.setAttribute("students", studentDetails);
				return "redirect:/page";
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return "index";
	}

	@GetMapping(value = "/emailAlreadyExists")
	@ResponseBody
	public Map<String, Boolean> emailAlreadyExists(@RequestParam String email) {
		Map<String, Boolean> response = new HashMap<>();
		Detail user = detailData.findByEmail(email);
		response.put("emailExists", user != null);
		return response;
	}

	@GetMapping(value = "/rollnoAlreadyExists")
	@ResponseBody
	public Map<String, Boolean> rollNoAlreadyExist(@RequestParam int roll_no) {
		Map<String, Boolean> response = new HashMap<>();
		Detail user = detailData.findByRoll_no(roll_no);
		response.put("rollnoExists", user != null);
		return response;
	}

	@RequestMapping(value = "/processStaffDetails")
	public String addStaffDetail(Detail detail, String email, Model model, HttpSession session,
			HttpServletResponse response) {
		response.setHeader("Cache-Control", "no-cache, no-store, must-revalidate");
		response.setHeader("Pragma", "no-cache");
		response.setHeader("Expires", "0");
		try {
			if (session.getAttribute("email") != null) {
				detailData.save(detail);
				String defaultPassword = "staff@123";
				String role = detail.getRole();
				Login userLogin = new Login();
				userLogin.setEmail(email);
				userLogin.setPassword(defaultPassword);
				userLogin.setRole(role);
				login.save(userLogin);
				int page = 0;
				return "redirect:/staffDetail?page=" + page;
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return "index";
	}

	@RequestMapping(value = "/staffDetail")
	public String staffDetail(@RequestParam int page, HttpSession session, HttpServletResponse response) {
		response.setHeader("Cache-Control", "no-cache, no-store, must-revalidate");
		response.setHeader("Pragma", "no-cache");
		response.setHeader("Expires", "0");
		try {
			int pageSize = 5;
			Pageable pageable = PageRequest.of(page, pageSize);
			String role = "staff";
			List<Detail> staffDetails = detailData.findAllByRole(role, pageable);
			session.setAttribute("staff", staffDetails);
			// Calculate total pages and set it in the session
			long totalStaffCount = detailData.countByRole(role);
			int totalPages = (int) Math.ceil((double) totalStaffCount / pageSize);
			session.setAttribute("totalStaffPages", totalPages);
			return "staffDetail";
		} catch (Exception e) {
			e.printStackTrace();
		}
		return "";
	}

	@RequestMapping(value = "/adminStudent")
	@ResponseBody
	public List<DetailDTO> adminStudent(@RequestParam int page, HttpSession session, HttpServletResponse response) {

		response.setHeader("Cache-Control", "no-cache, no-store, must-revalidate");
		response.setHeader("Pragma", "no-cache");
		response.setHeader("Expires", "0");
		int pageSize = 5; // Set the page size (number of elements per page)
		Pageable pageable = PageRequest.of(page, pageSize);
		String role = "student";
		List<Detail> studentLogin = detailData.findAllByRole(role, pageable);
		List<DetailDTO> studentDTOs = new ArrayList<>();
		for (Detail detail : studentLogin) {
			DetailDTO dto = new DetailDTO();
			dto.setRoll_no(detail.getRoll_no());
			dto.setName(detail.getName());
			dto.setYear(detail.getYear());
			dto.setStream(detail.getStream());
			dto.setDepartment(detail.getDepartment());
			dto.setEmail(detail.getEmail());
			studentDTOs.add(dto);
		}
		return studentDTOs;
	}

	@RequestMapping(value = "/adminStaff")
	@ResponseBody
	public List<DetailDTO> adminStaff(@RequestParam int page, HttpSession session, HttpServletResponse response) {
		response.setHeader("Cache-Control", "no-cache, no-store, must-revalidate");
		response.setHeader("Pragma", "no-cache");
		response.setHeader("Expires", "0");
		int pageSize = 5;
		String role = "staff";
		Pageable pageable = PageRequest.of(page, pageSize);
		List<Detail> staffLogin = detailData.findAllByRole(role, pageable);
		List<DetailDTO> staffDTOs = new ArrayList<>();
		for (Detail detail : staffLogin) {
			DetailDTO dto = new DetailDTO();
			dto.setName(detail.getName());
			dto.setEmail(detail.getEmail());
			dto.setStream(detail.getStream());
			dto.setDepartment(detail.getDepartment());
			staffDTOs.add(dto);
		}
		return staffDTOs;
	}

	@GetMapping("/updateStaff")
	public String showForm(@RequestParam("email") String email, Model model, HttpSession session,
			HttpServletResponse response) {
		response.setHeader("Cache-Control", "no-cache, no-store, must-revalidate");
		response.setHeader("Pragma", "no-cache");
		response.setHeader("Expires", "0");
		try {
			if (session.getAttribute("email") != null) {
				Detail staff = detailData.findByEmail(email);
				model.addAttribute("staff", staff);
				return "updateStaff";
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return "index";
	}

	@PostMapping("/updateStaff")
	public String updateStaff(@ModelAttribute Detail updatedStaff, Model model, HttpSession session,
			HttpServletResponse response) {
		response.setHeader("Cache-Control", "no-cache, no-store, must-revalidate");
		response.setHeader("Pragma", "no-cache");
		response.setHeader("Expires", "0");
		try {
			if (session.getAttribute("email") != null) {
				String email = updatedStaff.getEmail();
				String name = updatedStaff.getName();
				String stream = updatedStaff.getStream();
				String department = updatedStaff.getDepartment();
				String role = updatedStaff.getRole();
				System.out.println(updatedStaff);
				detailData.updateStaffDetail(email, name, stream, department, role);
				List<Detail> staffDetails = detailData.findByRole(role);
				session.setAttribute("staff", staffDetails);
				int page = 0;
				return "redirect:/staffDetail?page=" + page;
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return "index";
	}

	@GetMapping("/staffUpdate")
	public String showStaffForm(@RequestParam("email") String email, Model model, HttpSession session,
			HttpServletResponse response) {
		response.setHeader("Cache-Control", "no-cache, no-store, must-revalidate");
		response.setHeader("Pragma", "no-cache");
		response.setHeader("Expires", "0");
		try {
			if (session.getAttribute("email") != null) {
				return "staffUpdate";
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return "index";
	}

	@PostMapping("/staffUpdate")
	public String updateStaffForm(@ModelAttribute Detail updatedStaff, Model model, HttpSession session,
			HttpServletResponse response) {
		response.setHeader("Cache-Control", "no-cache, no-store, must-revalidate");
		response.setHeader("Pragma", "no-cache");
		response.setHeader("Expires", "0");
		try {
			if (session.getAttribute("email") != null) {
				String email = updatedStaff.getEmail();
				String name = updatedStaff.getName();
				String stream = updatedStaff.getStream();
				String department = updatedStaff.getDepartment();
				String role = updatedStaff.getRole();
				System.out.println(updatedStaff);
				detailData.updateStaffDetail(email, name, stream, department, role);
				Detail staffLogin = detailData.findByEmail(email);
				session.setAttribute("staff", staffLogin);
				return "staffPage";
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return "index";
	}

	@RequestMapping("/staffdelete")
	public String deleteStaff(@RequestParam("email") String email, Model model, HttpSession session,
			HttpServletResponse response) {
		response.setHeader("Cache-Control", "no-cache, no-store, must-revalidate");
		response.setHeader("Pragma", "no-cache");
		response.setHeader("Expires", "0");
		try {
			if (session.getAttribute("email") != null) {
				Login staffLogin = login.findByEmail(email);
				if (staffLogin != null) {
					login.delete(staffLogin);
				}
				String role = staffLogin.getRole();
				detailData.deleteById(email);
				List<Detail> staffDetails = detailData.findByRole(role);
				session.setAttribute("staff", staffDetails);
				int page = 0;
				return "redirect:/staffDetail?page=" + page;
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return "index";
	}

	@GetMapping("/updateStudent")
	public String showUpdateForm(@RequestParam("email") String email, Model model, HttpSession session,
			HttpServletResponse response) {
		response.setHeader("Cache-Control", "no-cache, no-store, must-revalidate");
		response.setHeader("Pragma", "no-cache");
		response.setHeader("Expires", "0");
		try {
			if (session.getAttribute("email") != null) {
				Detail student = detailData.findById(email).orElse(null);
				model.addAttribute("student", student);
				return "updateStudent";
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return "index";
	}

	@PostMapping("/updateStudent")
	public String updateStudent(@ModelAttribute Detail updatedStudent, Model model, HttpSession session,
			HttpServletResponse response) {
		response.setHeader("Cache-Control", "no-cache, no-store, must-revalidate");
		response.setHeader("Pragma", "no-cache");
		response.setHeader("Expires", "0");
		try {
			if (session.getAttribute("email") != null) {
				String email = updatedStudent.getEmail();
				String name = updatedStudent.getName();
				int roll_no = updatedStudent.getRoll_no();
				String year = updatedStudent.getYear();
				String stream = updatedStudent.getStream();
				String department = updatedStudent.getDepartment();
				String role = updatedStudent.getRole();
				detailData.updateStudentDetail(email, name, roll_no, year, stream, department, role);
				List<Detail> studentDetails = detailData.findByRole(role);
				session.setAttribute("students", studentDetails);
				return "redirect:/page";
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return "index";
	}

	@GetMapping("/studentUpdate")
	public String studentUpdateForm(@RequestParam("email") String email, Model model, HttpSession session,
			HttpServletResponse response) {
		response.setHeader("Cache-Control", "no-cache, no-store, must-revalidate");
		response.setHeader("Pragma", "no-cache");
		response.setHeader("Expires", "0");
		try {
			if (session.getAttribute("email") != null) {
				return "studentUpdate";
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return "index";
	}

	@PostMapping("/studentUpdate")
	public String studentUpdate(@ModelAttribute Detail updatedStudent, Model model, HttpSession session,
			HttpServletResponse response) {
		response.setHeader("Cache-Control", "no-cache, no-store, must-revalidate");
		response.setHeader("Pragma", "no-cache");
		response.setHeader("Expires", "0");
		try {
			if (session.getAttribute("email") != null) {
				String email = updatedStudent.getEmail();
				String name = updatedStudent.getName();
				int roll_no = updatedStudent.getRoll_no();
				String year = updatedStudent.getYear();
				String stream = updatedStudent.getStream();
				String department = updatedStudent.getDepartment();
				String role = updatedStudent.getRole();
				detailData.updateStudentDetail(email, name, roll_no, year, stream, department, role);
				Detail studentLogin = detailData.findByEmail(email);
				session.setAttribute("students", studentLogin);
				return "studentPage";
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return "index";
	}

	@RequestMapping("/deleteStudent")
	public String deleteStudent(@RequestParam("email") String email, Model model, HttpSession session,
			HttpServletResponse response) {
		response.setHeader("Cache-Control", "no-cache, no-store, must-revalidate");
		response.setHeader("Pragma", "no-cache");
		response.setHeader("Expires", "0");
		try {
			if (session.getAttribute("email") != null) {
				System.out.println(email);
				Login studentLogin = login.findByEmail(email);
				System.out.println(studentLogin);
				if (studentLogin != null) {
					login.delete(studentLogin);
				}
				String role = studentLogin.getRole();
				detailData.deleteById(email);
				List<Detail> studentDetails = detailData.findByRole(role);
				session.setAttribute("students", studentDetails);
				return "redirect:/page";
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return "index";
	}

	@RequestMapping("/viewStudents")
	public String viewStudents(String department, @RequestParam String email, Model model, HttpServletResponse response,
	        HttpSession session) {
	    response.setHeader("Cache-Control", "no-cache, no-store, must-revalidate");
	    response.setHeader("Pragma", "no-cache");
	    response.setHeader("Expires", "0");
	    try {
	        if (session.getAttribute("email") != null) {
	            List<Detail> students = detailData.findByRole("student");
	            if (students != null) {
	                // Example Stream operation: Filter students whose email contains "example.com"
	                List<Detail> filteredStudents = students.stream()
	                        .filter(student -> student.getDepartment().contains(department))
	                        .collect(Collectors.toList());

	                if (filteredStudents.isEmpty()) {
	                    throw new StudentsNotFoundException("No students found for department " + department);
	                }

	                model.addAttribute("students", filteredStudents);
	                return "viewStudents";
	            }
	            return "staffPage";
	        }
	    } catch (StudentsNotFoundException e) {
	        model.addAttribute("error", e.getMessage());
	        return "viewStudents"; // Create an errorPage.jsp or equivalent
	    } catch (Exception e) {
	        e.printStackTrace();
	    }
	    return "index";
	}

	@RequestMapping("/changepassword")
	public String changepasswordForm(@RequestParam("email") String email, Model model, HttpSession session,
			HttpServletResponse response) {
		response.setHeader("Cache-Control", "no-cache, no-store, must-revalidate");
		response.setHeader("Pragma", "no-cache");
		response.setHeader("Expires", "0");
		try {
			if (session.getAttribute("email") != null) {
				return "changepassword";
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return "index";
	}

	@PostMapping("/changepassword")
	public String changenewpassword(@ModelAttribute Login updatedpassword, Model model, HttpServletResponse response,
			HttpSession session) {
		response.setHeader("Cache-Control", "no-cache, no-store, must-revalidate");
		response.setHeader("Pragma", "no-cache");
		response.setHeader("Expires", "0");
		try {
			if (session.getAttribute("email") != null) {
				login.save(updatedpassword);
				return "index";
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return "index";
	}

	@RequestMapping("/updatepassword")
	public String updatepasswordForm(@RequestParam("email") String email, Model model, HttpSession session,
			HttpServletResponse response) {
		response.setHeader("Cache-Control", "no-cache, no-store, must-revalidate");
		response.setHeader("Pragma", "no-cache");
		response.setHeader("Expires", "0");
		try {
			if (session.getAttribute("email") != null) {
				return "updatepassword";
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return "index";
	}

	@PostMapping("/updatepassword")
	public String updatenewpassword(@ModelAttribute Login updatedpassword, Model model, HttpSession session,
			HttpServletResponse response) {
		response.setHeader("Cache-Control", "no-cache, no-store, must-revalidate");
		response.setHeader("Pragma", "no-cache");
		response.setHeader("Expires", "0");
		try {
			if (session.getAttribute("email") != null) {
				login.save(updatedpassword);
				return "index";
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return "index";
	}

	@GetMapping("/getDepartments")
	@ResponseBody
	public Map<String, String> getDepartments(@RequestParam String stream) {

		Map<String, String> departments = new HashMap<>();

		if (stream.equals("Engineering")) {
			departments.put("CSE", "CSE");
			departments.put("IT", "IT");
			departments.put("ECE", "ECE");

		} else if (stream.equals("Science")) {
			departments.put("Botany", "Botany");
			departments.put("Physics", "Physics");
			departments.put("Chemistry", "Chemistry");

		} else if (stream.equals("Arts")) {
			departments.put("English", "English");
			departments.put("Commerce", "Commerce");
			departments.put("Tamil", "Tamil");

		}

		return departments;
	}

	@RequestMapping(value = "/forgot")
	public String forgotPassword() {
		return "forgotPassword";
	}

	@PostMapping("/sendEmail")
	public String sendEmail(@RequestParam String email, @RequestParam int roll_no, Model model) {
		try {
			Detail user = detailData.findByEmail((email.trim()));
			if (user != null) {
				if (roll_no == user.getRoll_no()) {
					SimpleMailMessage message = new SimpleMailMessage();
					message.setTo(email);
					message.setSubject("Password Reset !!");
					message.setText("Dear user,\n\n yourpassword has been reset to 'user@123'.");
					// Send the email
					javaMailSender.send(message);
					return "index";
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		model.addAttribute("Error", "User name or password is incorrect");
		return "forgotPassword";
	}

	@GetMapping("/getDate")
	@ResponseBody
	public Map<String, String> getDate() {
		Map<String, String> dateTimeMap = new LinkedHashMap<>();
		LocalDate today = LocalDate.now();
		LocalTime currentTime = LocalTime.now();
		LocalDateTime localDateTime = LocalDateTime.now();
		ZoneId newYorkZone = ZoneId.of("America/New_York");
		ZoneId tokyoZone = ZoneId.of("Asia/Tokyo");
		//LocalDate tomorrow = today.plusDays(1);
		DayOfWeek dayOfWeek = today.getDayOfWeek();
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd-MM-yyyy HH:mm:ss");
		String formattedDateTime = localDateTime.format(formatter);
		//Native method
		//Current date
		Date currentDate = new Date();
	    Calendar calendar = Calendar.getInstance();
	    calendar.setTime(currentDate);
	    //Tomorrow date
	    Date tomorrowDate = new Date();
	    calendar.add(Calendar.DAY_OF_MONTH, 1);
	    tomorrowDate = calendar.getTime();
	    //Date formatter
	    SimpleDateFormat formatter1 = new SimpleDateFormat("yyyy-MM-dd");
	    String formattedDate = formatter1.format(currentDate);
	    dateTimeMap.put("Today", currentDate.toString());
		dateTimeMap.put("Current time", currentTime.toString());
		dateTimeMap.put("Current date and time", localDateTime.toString());
		dateTimeMap.put("Formatted date time", formattedDateTime.toString());
		dateTimeMap.put("Formatted date", formattedDate.toString());
		dateTimeMap.put("Day of week", dayOfWeek.toString());
		dateTimeMap.put("Tomorrow", tomorrowDate.toString());
		dateTimeMap.put("New York", localDateTime.atZone(newYorkZone).toString());
		dateTimeMap.put("Tokyo", localDateTime.atZone(tokyoZone).toString());
		return dateTimeMap;
	}

}
