//package com.example.demo;
//import org.springframework.beans.factory.annotation.Value;
//import org.springframework.scheduling.annotation.Scheduled;
//import org.springframework.stereotype.Component;
//
//@Component
//public class ScheduledTask {
//
//    @Scheduled(fixedRate = 5000) // This will run every 5 seconds
//    public void myScheduledTask() {
//        System.out.println("Scheduled task executed!");
//    }
//    @Scheduled(fixedDelay = 10000) // This will run every 10 seconds
//    public void oneMoreScheduledTask() {
//        System.out.println("Scheduled task executed using fixed delay!");
//    }
////    @Scheduled(cron = "0 */1 * * * *") // This will run every 1 minutes
////    public void specificTimeIntervalTask() {
////    	 System.out.println("Scheduled task executed using cron!");   
////    }
//    @Value("${my.scheduled.cron.expression}")
//    private String cronExpression;
//
//    @Scheduled(cron = "${my.scheduled.cron.expression}")
//    public void anotherScheduledTask() {
//    	System.out.println("Scheduled task executed using cron!"); 
//    }
//}
