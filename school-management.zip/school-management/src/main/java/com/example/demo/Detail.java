package com.example.demo;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OneToOne;
import javax.persistence.Table;
@Entity
@Table(name="detail")
public class Detail
{
	@Id
	@Column(name="email")
	private String email;
	@Column(name="name")
	private String name;
	@Column(name="roll_no")
	private int roll_no;
	@Column(name="year")
	private String year;
	@Column(name="department")
	private String department;
	@Column(name="role")
	private String role;
	@Column(name="stream")
	private String stream;
	public String getStream() {
		return stream;
	}
	public void setStream(String stream) {
		this.stream = stream;
	}
	public String getRole() {
		return role;
	}
	public void setRole(String role) {
		this.role = role;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getRoll_no() {
		return roll_no;
	}
	public void setRoll_no(int roll_no) {
		this.roll_no = roll_no;
	}
	public String getYear() {
		return year;
	}
	public void setYear(String year) {
		this.year = year;
	}
	public String getDepartment() {
		return department;
	}
	public void setDepartment(String department) {
		this.department = department;
	}
	@Override
    public String toString() {
        return "Detail{" +
                
                ", name='" + name + '\'' +
                ", roll_no=" + roll_no +
                ", year='" + year + '\'' +
                ", department='" + department + '\'' +
                   ",email='" + email + '\'' +
                    ",role='" + role + '\'' +
                '}';
    }
	@OneToOne(mappedBy="detail", cascade = CascadeType.ALL, orphanRemoval = true)	   
    private Login login;
	public Login getLogin() {
		return login;
	}
	public void setLogin(Login login) {
		this.login = login;
	}	
}
